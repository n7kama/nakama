import React, { useContext } from "react";
import { View, Text, StyleSheet, Button, FlatList, TouchableOpacity} from 'react-native';
import { withNavigation } from "react-navigation";

const Navbar = (props) => {
    return <View style={styles.view}>
        <TouchableOpacity style={styles.containers} onPress={() => {props.navigation.navigate("Index")}}>
            <Text style={styles.texts}>Logger</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.containers} onPress={() => {props.navigation.navigate("Exercise")}}>
            <Text style={styles.texts}>Exercise</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.containers} onPress={() => {props.navigation.navigate("Barcode")}}>
            <Text style={styles.texts}>Barcode</Text>
        </TouchableOpacity>


    </View>

}

const styles = StyleSheet.create({
    view: {
        flexDirection: "row",
        justifyContent: "center"
    },

    containers: {
        width: "30%", 
        height: 45, 
        borderColor: "black", 
        borderRadius: 5, 
        backgroundColor: "#5A5A5A", 
        justifyContent: "center",
        marginRight: 10,
      },
      texts: {
        fontSize: 30,
        alignSelf: 'center',
        color: "black"
    }
})

export default withNavigation(Navbar);